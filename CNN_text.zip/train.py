import numpy as np
import cv2
import os
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from keras.optimizers import adam_v2
from keras.preprocessing.image import ImageDataGenerator
from keras.utils.np_utils import to_categorical
from keras.models import Sequential
from keras.layers import Dense

from keras.layers import Dropout,Flatten
from keras.layers.convolutional import Conv2D,MaxPooling2D
import pickle


path = "myData"

#定义参数
testRatio = 0.2 #学习率
valRatio = 0.2
imageDimensions= (32,32,3)
batchSizeVal= 5
epochsVal = 15
stepsPerEpochVal = 1200

#加载数据集
images=[] #存放所有的图片
classNo =[] #存放图片的类别索引
mylist = os.listdir(path)
noOfClasses = len(mylist)
print("类别总数为:",noOfClasses)
print("加载数据集")

#遍历数据集并存放在列表中
for x in range(0,noOfClasses):
    myPicList = os.listdir(path + "/" + str(x))
    for y in myPicList:
        curimg = cv2.imread(path + "/" + str(x)+"/"+y)
        curimg = cv2.resize(curimg,(32,32))
        images.append(curimg)
        classNo.append(x)
    print(x,end=" ")
print("图片总数为:",len(images))

#将图片转换为numpy类型
images = np.array(images)
classNo = np.array(classNo)
# print(images.shape)
# print(classNo.shape)
#
#数据分割  分成训练集 测试集 验证集
X_train,X_test,y_train,y_test = train_test_split(images,classNo,test_size=0.2)
X_train,X_validation,y_train,y_validation = train_test_split(X_train,y_train,test_size=0.2)

print("训练集数量为:",len(X_train))
print("训练集数量为:",len(X_test))
print("验证集数量为:",len(X_validation))
#print(np.where(y_train==0))

#获取每个类别的数量
numOfSamples = []
for x in range(0,noOfClasses):
    numOfSamples.append(len(np.where(y_train==x)[0]))

plt.figure(figsize=(10,5))
plt.bar(range(0,noOfClasses,1),numOfSamples)
plt.title("No of Images for each Class")
plt.xlabel("Class No")
plt.ylabel("Number of Images")
plt.show()
#

#图片预处理 转为灰度图 and 图像均衡化
def preProcess(img):
    img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    img = cv2.equalizeHist(img)
    img = img/255
    return img

X_train = np.array(list(map(preProcess,X_train)))
X_test = np.array(list(map(preProcess,X_test)))
X_validation = np.array(list(map(preProcess,X_validation)))
#print(X_train[0].shape)

#  重塑图像数据
X_train = X_train.reshape(X_train.shape[0],X_train.shape[1],X_train.shape[2],1)
X_test = X_test.reshape(X_test.shape[0],X_test.shape[1],X_test.shape[2],1)
X_validation = X_validation.reshape(X_validation.shape[0],X_validation.shape[1],X_validation.shape[2],1)
# print(X_train[0].shape)

# # img = X_train[30]
# # img = cv2.resize(img,(300,300))
# # cv2.imshow('PreProcess',img)
# # cv2.waitKey(0)
#
# 图像数据增强
dataGen = ImageDataGenerator(width_shift_range=0.1, #改变宽度
                             height_shift_range=0.1, #改变高度
                             zoom_range=0.2, #缩放
                             shear_range=0.1, #剪切强度（以弧度逆时针方向剪切角度）
                             rotation_range=10 ) #随机旋转
dataGen.fit(X_train)

# 独热编码
y_train = to_categorical(y_train,noOfClasses)
y_test = to_categorical(y_test,noOfClasses)
y_validation = to_categorical(y_validation,noOfClasses)
#
#设计训练模型
def myModel():
    noOfFilters = 60 #过滤器
    sizeOfFilter1 = (5, 5)
    sizeOfFilter2 = (3, 3)
    sizeOfPool = (2, 2)
    noOfNodes = 500

    model = Sequential()
    model.add((Conv2D(noOfFilters, sizeOfFilter1, input_shape=(imageDimensions[0],
                                                               imageDimensions[1], 1), activation='relu')))
    model.add((Conv2D(noOfFilters, sizeOfFilter1, activation='relu')))
    model.add(MaxPooling2D(pool_size=sizeOfPool)) #保留主要特征的同时进行降维
    model.add((Conv2D(noOfFilters // 2, sizeOfFilter2, activation='relu')))
    model.add((Conv2D(noOfFilters // 2, sizeOfFilter2, activation='relu')))
    model.add(MaxPooling2D(pool_size=sizeOfPool))
    model.add(Dropout(0.5)) #减少过拟合

    model.add(Flatten()) #用来将输入“压平”，即把多维的输入一维化
    model.add(Dense(noOfNodes, activation='relu')) #全连接层
    model.add(Dropout(0.5))
    model.add(Dense(noOfClasses, activation='softmax'))

    model.compile(adam_v2.Adam(learning_rate=0.001), loss='categorical_crossentropy', metrics=['accuracy'])
    return model
#
model = myModel()
print(model.summary())
#
#开始训练模型
history = model.fit(dataGen.flow(X_train, y_train,
                              batch_size=batchSizeVal), #每次梯度更新的样本数。未指定，默认为32
                              steps_per_epoch=stepsPerEpochVal, #一个epoch包含的步数
                              epochs=epochsVal, #训练模型迭代次数
                              validation_data=(X_validation, y_validation), #用来评估损失，以及在每轮结束时的任何模型度量指标。
                              shuffle=1) #是否在每轮迭代之前混洗数据 布尔数值
#
model.save("my_model")
#
# 绘制训练结果
plt.figure(1)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.legend(['training', 'validation'])
plt.title('Loss')
plt.xlabel('epoch')
plt.figure(2)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.legend(['training', 'validation'])
plt.title('Accuracy')
plt.xlabel('epoch')
plt.show()
#
# #### EVALUATE USING TEST IMAGES
# score = model.evaluate(X_test, y_test, verbose=0)
# print('Test Score = ', score[0])
# print('Test Accuracy =', score[1])
#
# #### SAVE THE TRAINED MODEL
# # pickle_out = open("model_trained_10.p", "wb")
# # pickle.dump(model, pickle_out)
# # pickle_out.close()
